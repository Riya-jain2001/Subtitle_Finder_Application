// import { createRequire } from "module";
// const require = createRequire(import.meta.url);
const express = require("express");
const app = express();
const path = require("path");
const dir = path.join(__dirname, "public");
const d = __dirname;
// let search = document.getElementById("search");

app.use(express.static(dir));
app.use(express.static(d));
app.get("/", (req, res) => {
  res.sendFile(`d/index.html`);
});
app.get("/utube", (req, res) => {
  res.sendFile(`d/utube.html`);
});
app.get("/hollywood", (req, res) => {
  res.sendFile(`d/hollywood.html`);
});
app.get("/bollywood", (req, res) => {
  res.sendFile(`d/bollywood.html`);
});
app.get("/kdrama", (req, res) => {
  console.log(req);
  res.sendFile(`d/kdrama.html`);
});

app.listen(5000);
